player_manager.AddValidModel( "Cat","models/yevocore/cat/cat.mdl" )
list.Set( "PlayerOptionsModel",  "Cat","models/yevocore/cat/cat.mdl" )
player_manager.AddValidHands( "Cat", "models/yevocore/cat/cat_arms.mdl", 0, "00000000" )